﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationCore.Entities
{
    public class Vehicle
    {
        public enum type
        {
            Hatchback,
            Sedan,
            SUV,
            Crossover,
            Coupe,
            Convertible,
            Truck

        }
        public int id { get; set; }
        public string registrationNumber { get; set; }
        public string model { get; set; }
        public double weight { get; set; }
    }
}
