﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationCore.Entities
{
    public class Contrator
    {
        public int id { get; set; }
        public string Name { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
    }
}
