﻿namespace SizananiApplication.Data
{
    public class SizananiDataContext 
    {
    }
}
