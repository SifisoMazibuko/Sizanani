﻿using ApplicationCore.Entities;
using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SizananiApplication.Controllers
{
    public class VehicleController : Controller
    {

        private readonly IConfiguration _configuration;
        public string connString;

        public VehicleController(IConfiguration configuration)
        {
            _configuration = configuration;
            connString = configuration.GetConnectionString("data");

        }
        // GET: VehicleController
        public ActionResult Index()
        {
            return View();
        }

        // GET: VehicleController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: VehicleController/Create
        public ActionResult RegisterVehicle(Vehicle vehicle)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(connString))
                {
                    db.Open();
                    var data = "";
                    var vals = new
                    {
                        vehicle.model,
                        vehicle.registrationNumber,
                        vehicle.weight
                    };
                    string _vals = System.Text.Json.JsonSerializer.Serialize(vals);
                    data = db.ExecuteScalar<string>(
                        "exec Save_Vehicle_Details" +
                        "@vehicle_type = @vehicle_type, " +
                        "@registrationNumber = @registrationNumber, " +
                        "@model = @model, " +
                        "@weight = @weight",
                        vals);
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
            return View();
        }


        // GET: VehicleController/Edit/5
        public ActionResult Edit(int id, [FromBody] Vehicle vm)
        {
            if (id != vm.id)
            {
                return BadRequest();
            }
            using (IDbConnection db = new SqlConnection(connString))
            {
                db.Open();

                var sql = @"
                        UPDATE Vehicle 
                        SET  vehicle_type = @vehicle_type
                        ,RegistrationNumber = @RegistrationNumber 
                        ,model = @model
                        ,weight = @weight
                        WHERE Id = @Id";
                db.Execute(sql, vm);
            }
            return View();
        }


        // GET: VehicleController/Delete/5
        public ActionResult Delete(int id)
        {
                using (IDbConnection db = new SqlConnection(connString))
                {
                    db.Open();
                    var sqlStatement = "DELETE Vehicle WHERE Id = @Id";
                    db.Execute(sqlStatement, new { Id = id });
                }
                return Ok();
        }
    }
}
