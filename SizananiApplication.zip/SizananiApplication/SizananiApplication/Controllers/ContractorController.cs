﻿using ApplicationCore.Entities;
using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace SizananiApplication.Controllers
{
    public class ContractorController : Controller
    {

        private readonly IConfiguration _configuration;
        public string connString;

        public ContractorController(IConfiguration configuration)
        {
            _configuration = configuration;
            connString = configuration.GetConnectionString("data");

        }

        // GET: ContractorController
        public ActionResult Index()
        {
            return View();
        }

        // GET: ContractorController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ContractorController/Create
        public ActionResult RegisterContrator(Contrator contractor)
        {
            try
            {
                using (IDbConnection db = new SqlConnection(connString))
                {
                    db.Open();
                    var data = "";
                    var vals = new
                    {
                        contractor.Name,
                        contractor.email,
                        contractor.phone
                    };
                    string _vals = System.Text.Json.JsonSerializer.Serialize(vals);
                    data = db.ExecuteScalar<string>(
                        "exec Save_Contractor_Details" +
                        "@name = @name, " +
                        "@email = @email, " +
                        "@phone = @phone",
                        vals);
                }
            }
            catch (System.Exception ex)
            {
                throw new System.Exception(ex.Message);
            }
            return View();
        }


        // GET: ContractorController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }


        // GET: ContractorController/Delete/5
        public ActionResult Delete(int id)
        {
            using (IDbConnection db = new SqlConnection(connString))
            {
                db.Open();
                var sqlStatement = "DELETE Contrator WHERE Id = @Id";
                db.Execute(sqlStatement, new { Id = id });
            }
            return Ok();
        }

    }
}
