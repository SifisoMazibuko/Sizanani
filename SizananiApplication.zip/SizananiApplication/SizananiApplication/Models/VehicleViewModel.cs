﻿namespace SizananiApplication.Models
{
    public class VehicleViewModel
    {
        //public enum type
        //{
        //    Hatchback,
        //    Sedan,
        //    SUV,
        //    Crossover,
        //    Coupe,
        //    Convertible,
        //    Truck

        //}
        public string vehicle_type { get; set; }
        public string registrationNumber { get; set; }
        public string model { get; set; }
        public double weight { get; set; }

    }
}
