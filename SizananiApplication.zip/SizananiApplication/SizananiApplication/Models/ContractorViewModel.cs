﻿using System.ComponentModel.DataAnnotations;

namespace SizananiApplication.Models
{
    public class ContractorViewModel
    {
        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        [Phone]
        public string phone { get; set; }

    }
}
