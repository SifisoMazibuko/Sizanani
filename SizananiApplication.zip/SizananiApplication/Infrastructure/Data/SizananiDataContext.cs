﻿using ApplicationCore.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace Infrastructure.DataContext
{
    internal class SizananiDataContext : DbContext
    {
        public SizananiDataContext(): base() { }


        //public SizananiDataContext(DbContextOptions<SizananiDataContext> options)
        //    : base(options)
        //{
        //}
        public DbSet<Vehicle> vehicles { get; set; }
        public DbSet<ApplicationCore.Entities.Contrator> contractor { get; set; }



        //protected override void OnModelCreating(ModelBuilder builder)
        //{
            
        //}


    }
}
